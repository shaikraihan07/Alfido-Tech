from flask import Flask, request, jsonify
import joblib

# Create Flask app/server
app = Flask(__name__)

# Load trained model
model = joblib.load("model.pkl")

# Home route
@app.route('/')
def home():
    return "ML API is running!"

# Prediction route
@app.route('/predict', methods=['POST'])
def predict():

    try:
        data = request.get_json()

        features = data['features']

        prediction = model.predict([features])

        return jsonify({
            'prediction': int(prediction[0])
        })

    except Exception as e:
        return jsonify({
            'error': str(e)
        })
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)